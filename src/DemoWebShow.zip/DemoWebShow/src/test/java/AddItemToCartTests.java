import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.time.Duration;


public class AddItemToCartTests {
    WebDriver driver;

    @BeforeMethod
    public void setUp() {
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().window().maximize();
        driver.get("https://demowebshop.tricentis.com/");

        driver.findElement(By.xpath("//a[.='Log in']")).click();
        driver.findElement(By.xpath("//input[@id='Email']")).sendKeys("your_email@example.com");
        driver.findElement(By.xpath("//input[@id='Password']")).sendKeys("your_password");

        WebElement rememberMe = driver.findElement(By.xpath("//input[@id='RememberMe']"));
        if (!rememberMe.isSelected()) {
            rememberMe.click();
        }

        driver.findElement(By.xpath("//input[@value='Log in']")).click();

    }

    @Test
    public void AddItemToCart() {
        SoftAssert softAssert = new SoftAssert();

        // Шаг 1: Поиск и клик на второй товар
        driver.findElement(By.xpath("(//input[@class='button-2 product-box-add-to-cart-button'])[2]")).click();

        // Шаг 2: Проверка наличия алерта
        softAssert.assertTrue(isAlertPresent());

        // Шаг 3: Проверка наличия ошибки 409
        softAssert.assertTrue(isError409Present());

        // Проверка всех утверждений
        softAssert.assertAll();
    }

    // Метод для проверки наличия алерта
    private boolean isAlertPresent() {
            // Ожидание появления уведомления о добавлении товара
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

            // Ждем, пока элемент уведомления станет видимым и присваиваем его переменной
            WebElement notificationElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='bar-notification']/p")));

            // Проверка, что текст уведомления содержит нужное сообщение
            if (notificationElement != null) {
                String alertText = notificationElement.getText();
                return alertText.contains("The product has been added to your shopping cart");
            }
            return false;
        }


    // Метод для проверки наличия ошибки 409
    private boolean isError409Present() {
        return false;
    }

    @AfterMethod
    public void tearDown() {
        // Завершение работы браузера
        driver.quit();
    }
}
